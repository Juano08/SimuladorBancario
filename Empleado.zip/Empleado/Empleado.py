__author__ = "Juan"
__license__ = "GPL"
__version__ = "1.0.0"
__email__ = "juan.ruedav@campusucc.edu.co"

from Empleado.Fecha import Fecha 

class Empleado: 
    # Aqui inicia la declaracion de la clase

    '''#-------------------------------------
    # Atributos
    -----------------------------------------#'''

    nombre = ''
    apeliido = ''
    salario = 0

    '''#------------------------------------
    # 1 Masculino, 2 = Femenino
    ----------------------------------------#'''

    sexo = 0 

    '''#---------------------------------------------
    Asociacion
    ------------------------------------------------#'''

    fechaIngreso = Fecha()
    fechaNacimiento = Fecha() 