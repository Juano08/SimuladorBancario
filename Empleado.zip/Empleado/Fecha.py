__author__ = "Juan"
__license__ = "GPL"
__version__ = "1.0.0"
__email__ = "juan.ruedav@campusucc.edu.co"

class Fecha:
    # Aqui inicia la declaracion de mi clase
    #--------------------------------------#

    '''#-----------------------------------
    # Atributos
    -----------------------------------#'''
    
    dia= 0
    mes= 0
    anio= 0
    